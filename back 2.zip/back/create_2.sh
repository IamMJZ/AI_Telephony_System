python new_server.py load en 837f09a4-12c4-4b68-8cc3-d23842cf2128 python_bot_2 1
# 1 - load to the cuda
# 2 - language 
# 3 - id of the room 
# 4 - name of the bot
# 5 - GPU id to use