export PATH=$PATH:/usr/local/go/bin
go run main.go