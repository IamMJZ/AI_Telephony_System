# from colorama import Fore, Back, Style
reset = "\033[0m"
black = "\033[30m"
red = "\033[31m"
green = "\033[32m"
orange = "\033[33m"
blue = "\033[34m"
purple = "\033[35m"
cyan = "\033[36m"
lightgrey = "\033[37m"
darkgrey = "\033[90m"
lightred = "\033[91m"
lightgreen = "\033[92m"
yellow = "\033[93m"
lightblue = "\033[94m"
pink = "\033[95m"
lightcyan = "\033[96m"



def printred(text):
    print(f"{red}{text}{reset}")
def printgreen(text):
    print(f"{green}{text}{reset}")
def printorange(text):
    print(f"{orange}{text}{reset}")
def printblue(text):
    print(f"{blue}{text}{reset}")
def printpurple(text):
    print(f"{purple}{text}{reset}")
def printcyan(text):
    print(f"{cyan}{text}{reset}")
def printlightgrey(text):
    print(f"{lightgrey}{text}{reset}")
def printdarkgrey(text):
    print(f"{darkgrey}{text}{reset}")
def printlightred(text):
    print(f"{lightred}{text}{reset}")
def printlightgreen(text):
    print(f"{lightgreen}{text}{reset}")
def printyellow(text):
    print(f"{yellow}{text}{reset}")
def printlightblue(text):
    print(f"{lightblue}{text}{reset}")
def printpink(text):
    print(f"{pink}{text}{reset}")
def printlightcyan(text):
    print(f"{lightcyan}{text}{reset}")